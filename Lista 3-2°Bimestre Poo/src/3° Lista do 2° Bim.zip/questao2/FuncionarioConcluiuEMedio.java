package questao2;

public class FuncionarioConcluiuEMedio extends Empresa{
	
	public void registrarFConcluiuEMedio() {
		setEscola("Instituto Federal de Educa��o, Ci�ncia e Tecnologia do RN");
		System.out.println("Escola: "+getEscola());
	}

}
