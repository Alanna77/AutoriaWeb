package questao2;

public class FuncionarioN�oEstudou extends Empresa{

	public void registrarFNaoEstudou() {
		setNome("Pedro");
		setCodigofuncional(476647263);
		System.out.println("Nome: "+getNome());
		System.out.println("C�digo Funcional: "+getCodigofuncional());
	}

	

}
