package questao2;

public class FuncionarioConcluiuG extends Empresa{
	
	public void registrarFConcluiuGraduacao() {
		setUniversidade("UFRN");
		System.out.println("Universidade: "+getUniversidade());
	}

}
