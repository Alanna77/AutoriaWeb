package questao2;

public class FuncionarioConcluiuEnsino extends Empresa{
	
	public void registrarFConcluiuEnsino() {
		setEscola("Escola Estadual Jos� Bezerra");
		System.out.println("Escola: "+getEscola());
	}

}
