package questao1;

public class Pregui�a extends Animal{
	
	public void emitirSom() {
		System.out.println("ZZZ...");
	}

}
