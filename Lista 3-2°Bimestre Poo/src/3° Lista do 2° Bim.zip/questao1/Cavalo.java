package questao1;

public class Cavalo extends Animal{

	public void emitirSom() {
		System.out.println("IHIHIHIHI");
		
	}

}
