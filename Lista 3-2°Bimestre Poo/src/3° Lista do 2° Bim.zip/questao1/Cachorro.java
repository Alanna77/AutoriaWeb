package questao1;

public class Cachorro extends Animal{

	public void emitirSom() {
		System.out.println("AU, AU");
		
	}

}
