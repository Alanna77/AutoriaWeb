package questao4;

public class Produto {
	private String nomeloja;
	private int preco;
	protected String descricao = "Produto de inform�tica";
	
	public String getNomeloja() {
		return nomeloja;
	}
	public void setNomeloja(String nomeloja) {
		this.nomeloja = nomeloja;
	}
	public int getPreco() {
		return preco;
	}
	public void setPreco(int preco) {
		this.preco = preco;
	}
	public String getDescricao() {
		return "Produto de inform�tica";
	}


}
