package Questao2;

public class AgendaTeste {

	public static void main(String[] args) {
		Agenda a = new Agenda();
		a.armazenaPessoa("Alanna", "05/12/2004", 155);
		a.imprimePessoa(0);
		
		a.armazenaPessoa("Jullya", "21/01/2007", 167);
		a.imprimePessoa(1);
		
		a.armazenaPessoa("Raquel", "18/05/2005", 162);
		a.imprimePessoa(2);
	
		a.armazenaPessoa("Anderson", "21/11/1993", 165);
		a.imprimePessoa(3);
		
		a.armazenaPessoa("Amanda", "27/11/2008", 155);
		a.imprimePessoa(4);
		
		a.armazenaPessoa("Igote", "13/08/2003", 158 );
		a.imprimePessoa(5);
		
		a.armazenaPessoa("Andreza", "10/12/1998", 153);
		a.imprimePessoa(6);
		
		a.armazenaPessoa("Jessica", "31/03/2000", 171);
		a.imprimePessoa(7);
		
		a.armazenaPessoa("Fernanda", "17/09/2002", 174);
		a.imprimePessoa(8);
		
		a.armazenaPessoa("Ilanna", "05/06/2006", 157);
		a.imprimePessoa(9);
	}
	

	

	}


