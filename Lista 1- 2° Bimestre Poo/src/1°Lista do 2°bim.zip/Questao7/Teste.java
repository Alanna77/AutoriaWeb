package Questao7;

public class Teste {

	public static void main(String[] args) {
		ConversaoDaPiscina volumeI = new ConversaoDaPiscina();
		volumeI.litroEmCubico(1890);
		
		ConversaoDaPiscina volumeII = new ConversaoDaPiscina();
		volumeII.metrosCubicoEmLitro(1890);
		
		ConversaoDaPiscina volumeIII = new ConversaoDaPiscina();
		volumeIII.metrosCubicosEmPes(1890);

	}

}
