package Q2;

public class CamaroteSuperior extends IngressoVip{
	
	public void imprimeValor() {
		System.out.println("Camarote superior: 200 Reais.");
	}

}
