package Q2;

public class IngressoNormal extends Ingresso{
	
	public void Imprime() {
		System.out.println("Ingresso Normal");
	}
	
	public void imprimeValor() {
		System.out.println("50 Reais.");
	}

}
