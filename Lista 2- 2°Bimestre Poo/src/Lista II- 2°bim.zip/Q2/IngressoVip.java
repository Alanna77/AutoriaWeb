package Q2;

public class IngressoVip extends Ingresso{
	
	public void imprimeValor() {
		System.out.println("IngressoVip: 100 Reais.");
	}

}
