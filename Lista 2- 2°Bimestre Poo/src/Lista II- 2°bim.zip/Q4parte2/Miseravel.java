package Q4parte2;

public class Miseravel extends Pessoa{
	
	public void mendiga() {
		System.out.println("N�o tem nada");
	}

}
