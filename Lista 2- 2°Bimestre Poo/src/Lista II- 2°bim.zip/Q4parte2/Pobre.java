package Q4parte2;

public class Pobre extends Pessoa{
	
	public void trabalha() {
		System.out.println("Feirante");
	}

}
