package Q1;

public class Teste {

	public static void main(String[] args) {
		
		Vendedor vd = new Vendedor();
		vd.setNome("In�cio");
		vd.setGerente("Marcos");
		vd.imprimirDados();
		
		Gerente [] g = new Gerente[3];
	
		g[0] = new Gerente();
		g[1] = new Gerente();
		g[2] = new Gerente();
		g[4] = new Gerente();
		
	}
}
