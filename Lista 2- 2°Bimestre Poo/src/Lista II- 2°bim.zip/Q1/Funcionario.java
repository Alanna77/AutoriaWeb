package Q1;

public class Funcionario extends Pessoa{
	
	protected String departamento;
	protected double salario;

}
