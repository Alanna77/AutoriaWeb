package Q1;

public class Gerente extends Funcionario{
	
	protected String habilidadestecnicas;
	protected String setordetrabalho;
	protected String CH;

}
