package Q3;

public class Tecnico extends Funcionario{
	
	public void ganhoAnual(double bonus) {
		this.salario = (salario*12)*bonus;
	}
	
	

}
