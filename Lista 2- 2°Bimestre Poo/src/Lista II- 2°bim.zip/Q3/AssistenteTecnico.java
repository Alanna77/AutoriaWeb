package Q3;

public class AssistenteTecnico extends Assistente{
	protected double bonusSalarial;

	public double getBonussalarial() {
		return bonusSalarial;
	}

	public void setBonussalarial(double bonusSalarial) {
		this.bonusSalarial = bonusSalarial;
	}

}
