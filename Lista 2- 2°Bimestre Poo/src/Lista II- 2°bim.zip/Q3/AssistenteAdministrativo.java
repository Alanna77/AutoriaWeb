package Q3;

public class AssistenteAdministrativo extends Assistente{
	private String turnodetrabalho;

	public String getTurnodetrabalho() {
		return turnodetrabalho;
	}

	public void setTurnodetrabalho(String turnodetrabalho) {
		this.turnodetrabalho = turnodetrabalho;
	}

}
