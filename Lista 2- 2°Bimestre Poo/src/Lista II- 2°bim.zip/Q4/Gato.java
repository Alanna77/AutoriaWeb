package Q4;

public class Gato extends Animal{
	
	public String mia() {
		return "Miau";
	}

}
